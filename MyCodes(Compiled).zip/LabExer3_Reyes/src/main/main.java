package main;

import operation.*;

public class main
{


	public static void main(String args[])
	{
		Operation operation= new Operation();
		
		int a = 36;
		int b = 10;
		
		operation.getInt(a,b);
		
		operation.showDetails();
		
		
		
	}
}
