public class LabExer1v1
{

	public static void main (String args[])
	{
		System.out.println ("\n\n\n \t \t \t University of Santo Tomas \n \n");
		System.out.println ("Name: Reyes, Christian Joseph A. \t \t Student Number: 2013-061019\n");	
		System.out.println ("Semester / School Year: 2013-2014 \t \t Course: BSCS \n\n\n");
		System.out.println ("     Subject Code \t Description \t \t Schedule \t     No.of Units \n");
		System.out.println ("  1  PSY 1 \t\t GENERAL PSYCHOLOGY \t M 11am-01pm Rm. 44 \t 3");
		System.out.println ("\t\t\t\t\t\t W 12pm-1pm Rm. 54 \n");
		System.out.println ("  2  PHYS 102 \t\t PHYSICS I \t\t Th 2pm-3pm Rm.45 \t 2");
		System.out.println ("\t\t\t\t\t\t S 3pm-4pm Rm.47 \n");
		System.out.println ("  3  MATH 104 \t\t ANALYTIC GEOMETRY \t Th 11am-1pm Rm. 45 \t 2 \n\n");
		System.out.println ("  4  CS 201 \t\t DISCRETE STRUCTURES I \t MWF 3pm-4pm Rm.44 \t 3 \n\n");
		System.out.println ("  5  PE \t\t ARNIS \t\t\t W 7am-9am GS \t\t 2 \n\n");
		System.out.println ("\t\t\t\t\t\t\t Total Units: \t 12");
	}
}