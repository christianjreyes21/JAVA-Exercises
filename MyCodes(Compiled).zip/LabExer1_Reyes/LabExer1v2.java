public class LabExer1v2
{

	public static void main (String args[])
	{
		System.out.println ("\n\n\n \t \t \t University of Santo Tomas \n \n"
		+"\nName: Reyes, Christian Joseph A. \t \t Student Number: 2013-061019\n"	
		+"\nSemester / School Year: 2013-2014 \t \t Course: BSCS \n\n\n"
		+"\n     Subject Code \t Description \t \t Schedule \t     No.of Units \n"
		+"\n  1  PSY 1 \t\t GENERAL PSYCHOLOGY \t M 11am-01pm Rm. 44 \t 3"
		+"\n\t\t\t\t\t\t W 12pm-1pm Rm. 54 \n"
		+"\n  2  PHYS 102 \t\t PHYSICS I \t\t Th 2pm-3pm Rm.45 \t 2"
		+"\n\t\t\t\t\t\t S 3pm-4pm Rm.47 \n"
		+"\n  3  MATH 104 \t\t ANALYTIC GEOMETRY \t Th 11am-1pm Rm. 45 \t 2 \n\n"
		+"\n  4  CS 201 \t\t DISCRETE STRUCTURES I \t MWF 3pm-4pm Rm.44 \t 3 \n\n"
		+"\n  5  PE \t\t ARNIS \t\t\t W 7am-9am GS \t\t 2 \n\n"
		+"\n\t\t\t\t\t\t\t Total Units: \t 12");
	}
}